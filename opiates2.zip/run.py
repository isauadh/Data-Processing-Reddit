import os
import csv
import json

destination = 'CSV'
directory = 'opiates'
os.mkdir(destination)
index_Dict = {}
index = 0

for filename in os.listdir(directory):
    print(filename)
    with open(os.path.join(directory, filename)) as json_file:
        data = json.load(json_file)

    toStore = os.path.join(destination, str(index))
    os.mkdir(toStore)
    with open(os.path.join(toStore, 'comment.csv'), 'w', newline='', encoding='utf-8') as csv_1, open(os.path.join(toStore, 'submission.csv'), 'w', newline='', encoding='utf-8') as csv_2:
        writer1 = csv.writer(csv_1)
        writer2 = csv.writer(csv_2)
        writer1.writerow(['Comment_ID', 'Comment_Submission', 'Comment_Text', 'Subreddit'])
        writer2.writerow(['Submission_ID', 'Submission_Title', 'Submission_Text', 'Subreddit'])
        printCommentList = []
        printSubmissionList = []
        for key, values in data.items():
            index_Dict[index] = key
            index += 1
            value = values[0]
            for key1, values1 in value.items():
                if (key1 == '0_comments'):
                    for value1 in values1:
                        for key2, values2 in value1.items():
                            for value2 in values2:
                                printCommentList = [key2]
                                for key3, value3 in value2.items():
                                    printCommentList.append(value3)
                                writer1.writerow(printCommentList)
                if (key1 == '1_submissions'):
                    for value1 in values1:
                        for key2, values2 in value1.items():                                
                            for value2 in values2:
                                printSubmissionList = [key2]
                                for key3, value3 in value2.items():
                                            printSubmissionList.append(value3)
                                writer2.writerow(printSubmissionList)

with open(os.path.join(destination, 'Index'), "w") as outputfp:
    outputfp.write(json.dumps(index_Dict, sort_keys = True, indent = 4))